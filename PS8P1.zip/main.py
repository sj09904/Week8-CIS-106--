def userenter (yes, no):
  while continue = 'yes':
    Function forecast
  if month = Jan, Feb or March:
    Nextmonthsales = sales * 1.1
  else:
    if month = Apr, May Jun:
      Nextmonthsales = sales * 1.15
    else:
      if month = Jul, Aug or Sep:
        Nextmonthsales = sales * 1.20 
      else: 
         Nextmothsales = sales * 1.25
  return Nextmonthsales

lastname = input("Enter last name ")
month = input("Enter mnoth ")
sales = float(input("Enter sales "))
continue = input("Enter yes or no")
 
print(Nextnothsales)

